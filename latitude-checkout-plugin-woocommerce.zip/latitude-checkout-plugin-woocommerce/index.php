<?php
// Silence is golden.
 